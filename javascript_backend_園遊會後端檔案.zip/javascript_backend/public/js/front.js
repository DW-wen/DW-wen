const getBtn = document.getElementById('get');
const postBtn = document.getElementById('post');
const input = document.getElementById('input');

const baseURL = '//172.20.10.6:3000/'  // 要傳輸和接收資料的位置

getBtn.addEventListener('click', getInfo);
postBtn.addEventListener('click', postInfo);

async function getInfo(e){ 
    e.preventDefault(); // 預防刷新葉面
    // 接收訊息
    const res = await fetch(baseURL + "info", { // 除了 method: GET ，好像還有別的可以加入在 fetch -> GET 裡的其他東東，要查
        method: 'GET' // 使用 GET 獲得資料
    });

    
    console.log(res);
    const data = await res.json(); // 從字串解成 object
    input.value = data.info;
    alert(data.sound);
}

async function postInfo(e){
    const options = { // 測試用
        input: input.value,
        test: 2
    };
    //console.log(34);
    e.preventDefault(); // 預防刷新葉面
    //if(inside === '') return;
    //console.log(res);
    const res = await fetch(baseURL, { 
        method: 'POST', // 使用 POST 傳輸資料
        headers: {
            "Content-Type": 'application/json' // 設定傳輸種類為字串方法，還能設定其他檔案類型
        },
        body: JSON.stringify(options) // 打包成字串方式後傳輸
    });
}
/*
//本地端存儲寫法
const Datastore = require('nedb') // 使用 nedb 模塊存資料
// 建立本端資料庫
// 資料庫建立方式 filename.db
const database = new Datastore({  // 此法設定資料庫較穩定
  filename: './dataStore/database.db', // 先進到資料夾後，打開存資料的 database.db
  autoload: true // 自動運行資料庫
});

//另一種 nedb 新增寫法 // 看狀況使用
//const database = new name("db.db") // 這樣會自動創建
//database.loadDatabase();



// 插入
databaseInsert(val);
function databaseInsert(parameter) { // parameter 是傳入的值
  database.insert(parameter); 
}

// 搜尋
database.find({
  status: 1 // 查詢項目，記得包在 object 裡
}, (err, output) => {
  if(err){
    console.log(err);
  }
  console.log('succed to find it');
  output.forEach((element, index) => {
    console.log(element);  // forEach 會一直跑 object 陣列，直到全部跑完
  });
});

//removeData();
function removeData (){
  database.remove({

  }, (err, output) => {

  });
}
*/

const cors = require('cors'); // 一個前後端連接協定，詳細功能不了解，只知道可以跑
const express = require('express'); // 架後端需要用的框架
require('dotenv').config(); // 處理環境變量 env  

// 下面兩個功能目前用不到
//const https = require('https');
//const fs = require('fs');

// 這是 nodeman ，可以在按存檔後自動更新 server，但我沒深入研究，所以不能用，但這功能很好用，不用一直衝開伺服器
const { name } = require('nodeman/lib/mustache'); 

const app = express() 
const port =  3000 ; // 端口在 3000
//const portNotLocal = process.env.PORT; // 這一行是在處理外接網站時用的，暫且不用管


app.use(cors()); // 新增才能正常傳輸資料往返前後端
app.use(express.static('public')); // 選取並僅能使用特定資料夾資料，資安方面才這樣搞
app.use(express.json()); // 導入 json 函式
app.use(express.json({limit: '100mb'})); // 限制檔案輸入大小


let test_info = JSON.stringify(val); // 將 object 轉成字串


/*
// 以下為 mongodb 處理
// 尚未有 delete 功能

// 參考資料 :https://reurl.cc/ez6dYW

const Hi = require('./models/blog'); // 呼叫預先指定好的資料儲存模板
const mongoose = require('mongoose'); // 呼叫 mongoose 模塊

// 這一行是連接資料庫，帳號密碼都要好好打，不能有空格和錯誤
// 連接資料庫成功時，會跳出連接伺服器成功，並且去聆聽 port 3000 端口
const mongodbURL = 'mongodb+srv://<account>:<password>@cluster0.cmjndt1.mongodb.net/school_data';
mongoose.connect(mongodbURL) 
  .then((result) =>  app.listen(port, () => { 
    console.log(`Server has on port: ${port} \nServer is connected to MongoDB`) 
  })) 
  .catch((err) => console.log(err) );

//下方這個是測試用的資料，用 Hi 是因為實驗用，可更換
const blog = new Hi({
  title: 'adfbvdc',
  snippet: 'b',
  body: 'abcd',
  status: 5
});


// 儲存進入 mongodb

function saveMongodb (){

  blog.save()
  .then((result) => { // 正確處理
    console.log(result);
  })
  .catch((err) => { // 錯誤處理
    console.log(err);
  });

}
//saveMongodb();

// 尋找 mongodb 的內容
function findMongodb () {
// 注意是用 Hi 並非 blog，且 find 裡面包的是 object，他可以包很多個查詢值，也可以只包一個。 find 會跳出所有察遜到的鍵值

  Hi.find({status: 5, body: 'abcd'}) 
  .then((result) => {
    console.log(result);
  })
  .catch((err) => {
    console.log(err);
  })

}
//findMongodb();

//刪除 mongodb 內容
function removeMongodb () { // 這功能好像還有 remove 無法使用，但 deleteMany 和 deleteOne 可以使用
  Hi.deleteMany({status: 5})
  .then((result) => {
    console.log('success');
  })
  .catch((err) => {
    console.log(err);
  })
}
//removeMongodb();

*/




// req: 前端到後端 res: 後端到前端
// 先把他註解掉的原因，是因為上面的 mongodb 要用，mongodb 拿下面註解程式碼，當成測試他有順利抓到 mongodb 資歷庫，回傳聆聽 port:3000
app.listen(port, () => {
  console.log(`Server has on port: ${port}`)
});

// 下面三行註解，是在模擬另外幾個狀況下，在參考資料裡有教學
app.get('/info', (req, res) => {
  //const {dynamic} = req.params; // 解除 object 狀態
  //const {key} = req.query; // params: jame // query = key
  //console.log(dynamic, key);

    res.status(200).json(test_info); // 回傳值，並且顯示狀態 200 代表傳輸
});


app.post('/', (req, res) => {
  const parcel = req.body; // 獲得前端資料 // body 是資料的地方
  console.log(parcel.test, parcel.input);
  
  // 後端傳給前端是否有正確收到
  if(!parcel){
    return res.status(500).send({status: failed}); 
  }
  res.status(200).send({status: 'received'});
});

/*
資料儲存方法
// 話說下面有很多要修改的儲存方式，然後我忘記要改什麼 :)
// initialize webpage
// front -> back
let info_sgin = {
  account: "207", // 包成 string
  position: "chef", // 職位
  password: "12345678" // string type
};

// back -> front
let info_webpage = {
  webpage_data: "<html></html>" 
  // i'll response webpage for you, 
  // you save webpage in localStorage
};


// sending info between front and back
let info_order = {
  account: "207", //class name
  position: "position", // 職位 -> ex: 飲料製作 || 熱狗堡處理

  // 餐點名稱_售價
  expense: 40, // total cost
  beverages: {
    // example
    soda_20: 1, // send me in digit
    juice_35:2
  },
  dishes: {
    // example
    marshmellow_10: 2, // send me in digit
    instant_oodle_35: 0 
  },

  status: "in order / finished", // not yet -> in order, finished -> finished
  orderNumber: 1, // send me in digit
  orderTime: {  // 先在前端將時間設定好
    date: "2024/5/11",
    time: "10:20",
    estimated_finished_time: "10:25",
    estimated_time: 5 // save in digit
  }, 
  
};
*/

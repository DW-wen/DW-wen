const mongoose = require('mongoose'); // 引入 mongoose 模塊
const Schema = mongoose.Schema; // 不懂但會跑，可以查目的

// 用 required: true ， 格式必定要正確 -> 這很重要
// 設定傳輸和接收時的資料型態 
const blogSchema = new Schema({  // 只知道這樣設可以跑，不知道意義
    title: {
        type: String,
        required: true
    },
    snippet: {
        type: String,
        required: true
    },
    body: {
        type: String,
        required: true
    },
    status: {
        type: Number,
        required: true
    }
    
}, { timestamps: true}); // 紀錄是在何時傳資料

const Hi = mongoose.model('data', blogSchema); // 更改 data，會在 mongodb 新增另外一個儲存伺服器，並且會顯示為 " data's' "，會在尾端加 s 
module.exports = Hi; // 將 Hi 函式匯出給其他程式碼用